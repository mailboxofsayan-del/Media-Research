# Contributing

Open an issue describing the methodological or teaching need. For proposed changes, include rationale, relevant sources where applicable, an example, and limitations. Clearly distinguish validated instruments from original draft items. Do not submit personal data, restricted media, or invented empirical findings. For code changes, provide a small reproducible example and expected output. The maintainer reviews contributions before merging.
