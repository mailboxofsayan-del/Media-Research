"""Two-coder nominal agreement. Standard library only; no missing ratings allowed."""
import argparse
import csv
from collections import Counter


def agreement(pairs):
    if not pairs:
        raise ValueError("At least one pair is required")
    if any(not a.strip() or not b.strip() for a, b in pairs):
        raise ValueError("Missing ratings: resolve or document exclusion before analysis")
    n = len(pairs)
    observed = sum(a == b for a, b in pairs) / n
    left = Counter(a for a, _ in pairs)
    right = Counter(b for _, b in pairs)
    expected = sum(left[k] * right[k] for k in left.keys() | right.keys()) / n**2
    kappa = None if expected == 1 else (observed - expected) / (1 - expected)
    return n, observed, kappa


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", help="CSV with item_id,coder_a,coder_b columns")
    args = parser.parse_args()
    try:
        with open(args.csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            if not {"item_id", "coder_a", "coder_b"}.issubset(reader.fieldnames or []):
                raise ValueError("Required columns: item_id,coder_a,coder_b")
            rows = list(reader)
        ids = [row["item_id"] for row in rows]
        if any(not x for x in ids) or len(set(ids)) != len(ids):
            raise ValueError("Item IDs must be present and unique")
        n, observed, kappa = agreement([(row["coder_a"] or "", row["coder_b"] or "") for row in rows])
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(f"Paired units: {n}")
    print(f"Percent agreement: {observed:.2%}")
    print("Cohen's kappa: " + ("undefined (expected agreement is 1)" if kappa is None else f"{kappa:.4f}"))


if __name__ == "__main__":
    main()
