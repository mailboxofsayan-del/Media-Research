# Semi-structured interview guide

Before recording, explain consent, confidentiality limits, voluntary participation, the right to skip questions, recording arrangements, and withdrawal deadlines. Use participant codes and secure storage.

1. Tell me how news usually reaches you during a typical day.
2. Can you recall a recent news item that attracted your attention? What stood out?
3. How do you decide whether a source or claim is credible? Ask for a specific example.
4. Describe a time when different outlets presented the same event differently.
5. What role, if any, do friends, family, or online communities play in your interpretation?
6. Tell me about a time you changed your view after encountering additional information.
7. Are there perspectives you find difficult to access? Why?
8. Is there anything we have missed?

Use neutral probes: “Could you explain?” “What happened next?” Avoid assuming misinformation exposure or political affiliation. Record contextual field notes and researcher positionality. Specify whether analysis is reflexive thematic analysis, codebook thematic analysis, or another approach; use quality criteria coherent with that choice. Do not impose intercoder reliability as a universal requirement for interpretive qualitative work.
