# Study plan / preregistration worksheet

- Working title and research question:
- Contribution and specific gap supported by a literature review:
- Theoretical lens (e.g., framing, agenda-setting, uses and gratifications):
- Explain how each construct becomes an observable variable; distinguish media salience from audience effects.
- Hypotheses, if confirmatory, and rationale:
- Exploratory questions, separately identified:
- Population, geography, languages, platforms/outlets, and date range:
- Sampling frame, sampling method, selection procedure, sample-size rationale:
- Unit of sampling, unit of analysis, duplicate handling, and inclusion/exclusion rules:
- Data-access permissions and ethics approval or exemption determination:
- Instruments, pilot plan, coder training, and planned reliability assessment:
- Outcome and explanatory variables, confounders, missing-data rules:
- Planned analysis, uncertainty estimates, and multiple-testing approach:
- Qualitative analytic approach, reflexivity, negative cases, and audit trail:
- Limits to generalizability and causal interpretation:
- Data/code sharing plan and justified restrictions:
- Timestamped amendments and deviations from this plan:
