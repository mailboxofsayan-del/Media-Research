# Data management and reproducibility

- Assign pseudonymous IDs; keep any linkage key separately with restricted access.
- Record provenance, collection dates, access conditions, and transformations.
- Keep raw data read-only; analyze a documented working copy.
- Maintain a variable dictionary, missing-value codes, codebook versions, and amendment log.
- Set retention and deletion schedules consistent with consent and institutional requirements.
- Assess reidentification risk before sharing quotations, small cells, or platform identifiers.
- Share analysis code, permissible metadata, and synthetic examples when raw data cannot be released.
- Label every synthetic record and never present it as participant evidence.
- Report negative findings, exclusions, deviations, uncertainty, and limitations.
- Record software versions and reproducible execution instructions.
