# Exploratory digital-media questionnaire

UNVALIDATED DRAFT: these original items are not a published psychometric scale. Do not label them validated or combine them into a score without a theoretical and empirical justification.

## Participant introduction
Describe the research purpose, investigator contact, eligibility, voluntary participation, expected duration, data use, retention, and withdrawal limits. Obtain locally appropriate informed consent. Seek approval for research involving minors or vulnerable groups. Do not collect passwords, account handles, or unnecessary identifiers.

## Questions
1. Are you eligible under the study's stated age and location criteria? Yes / No / Prefer not to answer. End the questionnaire if eligibility cannot be established.
2. During the last seven days, on how many days did you access news through social media? 0–7 / Prefer not to answer.
3. On a typical day when you did so, approximately how much time did you spend? Under 15 minutes / 15–29 / 30–59 / 60–119 / 120 or more / Unsure / Not applicable.
4. Which sources did you use? News organization websites; television/radio; print; social platforms; messaging apps; other; prefer not to answer. Select all that apply.
5. What was your principal reason for using social media for news? Staying informed; discussion; entertainment; professional/academic work; other; not applicable.
6. How often did you check a news claim against another source before sharing it during the last seven days? Never / Rarely / Sometimes / Often / Always / Did not share news / Prefer not to answer.
7. How credible did you generally find the news you encountered on social media in that period? Not at all / Slightly / Moderately / Very / Extremely / No exposure / Unsure.
8. Describe an occasion when you doubted a news item. What did you do? Optional free text; ask participants to omit names and identifying details.

## Adaptation and analysis
Conduct cognitive interviews and a pilot; document translation and cultural adaptation. Keep not-applicable, unsure, and refusal codes separate from substantive responses. Predefine valid denominators and report item-level distributions. Frequency, motivations, and perceived credibility are distinct constructs. Self-reports are subject to recall and social-desirability bias; convenience samples do not support population prevalence claims.
