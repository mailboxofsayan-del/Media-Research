# News-framing pilot codebook

## Scope and procedure
Unit: one published news article, excluding user comments, advertisements, and linked articles. Register the outlet, publication date, article identifier, language, retrieval date, and inclusion decision. Retain only media content that may lawfully be stored; share identifiers or derived codes where redistribution is restricted.

Code the headline and article body together. Coders work independently after training. Record uncertain cases and evidence excerpts internally; avoid republishing identifiable or copyrighted excerpts unnecessarily. Establish article boundaries and translation rules in advance.

| Variable | Values | Decision rule |
|---|---|---|
| dominant_frame | responsibility; conflict; human_interest; economic_consequences; other; unclear | Responsibility emphasizes who causes or should solve a problem; conflict emphasizes contest between actors; human interest foregrounds individual experience; economic consequences foreground financial/material outcomes. Select the frame developed in the most paragraphs; use headline emphasis to resolve a tie; otherwise use unclear. Record other only for a clear frame outside these categories. |
| source_diversity | integer >=0; missing | Count distinct explicitly attributed people or organizations, counting repeated references once. Anonymous sources count as separate only when explicitly distinguished in the article. Use missing when the text is incomplete. |
| evidence_type | data; testimony; documents; mixed; none; unclear | Record the principal basis for the central claim: numerical evidence, attributed personal accounts, documentary material, multiple equally central types, no explicit supporting evidence, or insufficient text. |
| counter_position | present; absent; unclear | Present requires an attributed viewpoint that challenges the article's central interpretation, rather than a passing mention of disagreement. |

## Reliability
Pilot across relevant outlets and languages. Record sample selection, number of units, coder training, codebook version, and disagreements. Calculate reliability on independent ratings before adjudication. For multiple coders, missing values, ordinal categories, or repeated units, select an appropriate reliability method; the supplied two-coder kappa script is deliberately limited. Report category distributions and percent agreement alongside kappa, which can be affected by marginal imbalance. Do not treat any single cutoff as proof of validity. Revise ambiguous rules, then assess the revised codebook on fresh independently coded material.
